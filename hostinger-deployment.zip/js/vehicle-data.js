/**
 * A+ Auto Centre - Vehicle Inventory Data
 * Source: Scraped from NLClassifieds.com/APlusAutoCentre
 * Last Updated: December 8, 2024
 */

const vehicleInventory = [
    {
        id: 1,
        year: 2014,
        make: "Hyundai",
        model: "Elantra",
        price: 4995,
        priceType: "firm",
        mileage: "N/A",
        transmission: "Automatic",
        fuelType: "Gasoline",
        engine: "4-Cylinder",
        bodyType: "Sedan",
        certified: true,
        features: ["Automatic Transmission", "4-Cylinder", "Excellent Gas Mileage", "Fresh Oil Change", "Detailed"],
        description: "In the market for a second car or a car for that special someone attending school or university, well here it is! Car will be sold inspected and fully serviced with a fresh oil and filter change. Car has a automatic transmission with a 4 cylinder engine that provides excellent gas mileage. Car was just detailed inside and out.",
        status: "available",
        imageUrl: "https://dn74k69h2p3fn.cloudfront.net/2025/12/01/1764614620177_3477369_sm.jpg"
    },
    {
        id: 2,
        year: 2016,
        make: "Hyundai",
        model: "Elantra",
        price: 5995,
        priceType: "obo",
        mileage: "154,000",
        transmission: "Automatic",
        fuelType: "Gasoline",
        engine: "4-Cylinder",
        bodyType: "Sedan",
        certified: true,
        features: ["Automatic Transmission", "4-Cylinder", "Excellent Gas Mileage", "Fresh Oil Change", "Sporty"],
        description: "New to inventory is this little sporty Hyundai Elantra. Car has a automatic transmission with a 4 cylinder engine that provides excellent gas mileage. Car will be sold fully inspected and serviced with a fresh oil change to get you started the right way.",
        status: "available",
        sale: true,
        imageUrl: "https://dn74k69h2p3fn.cloudfront.net/2024/06/06/1717682473208_3539292_md.jpg"
    },
    {
        id: 3,
        year: 2012,
        make: "Honda",
        model: "CRV",
        price: 9995,
        priceType: "obo",
        mileage: "135,000",
        transmission: "Automatic",
        fuelType: "Gasoline",
        engine: "4-Cylinder",
        bodyType: "SUV",
        drivetrain: "AWD",
        certified: true,
        features: ["AWD", "4-Cylinder", "Low Mileage", "Excellent Gas Mileage", "Fresh Oil Change", "Detailed"],
        description: "In excellent shape inside and out with low kms with just 135k kms. Comes with a 4 cylinder engine with automatic transmission with AWD that gives you great gas mileage. Will be sold inspected and fully serviced with a great oil and filter change. Just has a detail inside and out, paint and fabric are in awesome shape.",
        status: "available",
        imageUrl: "https://dn74k69h2p3fn.cloudfront.net/2025/06/23/1750679465523_3645862_lg.jpg"
    },
    {
        id: 4,
        year: 2015,
        make: "BMW",
        model: "X3",
        price: 10995,
        priceType: "obo",
        mileage: "180,523",
        transmission: "Automatic",
        fuelType: "Gasoline",
        bodyType: "SUV",
        drivetrain: "AWD",
        certified: true,
        features: ["AWD", "Heated Leather Seats", "Heated Steering Wheel", "Heated Mirrors", "Premium Package", "Fresh Oil Change", "Fully Loaded"],
        description: "Black Beauty!!! Just arrived is this X3 with 180kms. Selling inspected and fully serviced with a fresh oil and filter change. Has every available option for the year! Beautiful heated leather seats, heated steering wheel, heated mirrors, you name it this BMW has it!",
        status: "available",
        imageUrl: "https://dn74k69h2p3fn.cloudfront.net/2025/12/04/1764868531827_3685733_md.jpg"
    },
    {
        id: 5,
        year: 2013,
        make: "Kia",
        model: "Soul",
        price: 6995,
        priceType: "firm",
        mileage: "Low",
        transmission: "Automatic",
        fuelType: "Gasoline",
        bodyType: "Hatchback",
        certified: true,
        features: ["Low Mileage", "Winter Tires Included", "Fresh Oil Change", "Great Condition"],
        description: "Selling a Kia Soul inspected with a fresh oil change. Car is in great shape inside and out and drives even better. Comes with winter tires already installed to face old man winter.",
        status: "available",
        imageUrl: "https://dn74k69h2p3fn.cloudfront.net/2025/01/02/1735835236574_3603720_md.jpg"
    }
];

// Export for use in inventory page
if (typeof module !== 'undefined' && module.exports) {
    module.exports = vehicleInventory;
}
